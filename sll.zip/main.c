/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
struct student
{
    char usn[20],nm[20],br[20],sem[20],phno[20];
};
typedef struct student st;
struct node
{
    st d;
    struct node *link;
};
typedef struct node nd;
nd* i_f(nd *);
nd* d_f(nd *f);
nd* i_r(nd *);
nd* d_r(nd *);
void display(nd *);
int main()
{
    nd *first=0;
    int ch;
    for(;;)
    {
        printf("1:insert front\n2:insert rear\n3:delete front\n4: delete rear\n5:display\n6:exit\n");
        printf("Enter the choice\n");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1: first=i_f(first); break;
            case 2: first=i_r(first); break;
            case 3: first=d_f(first); break;
            case 4: first=d_r(first); break;
            case 5: display(first); break;
            default : exit(0);
        }
    }
}

nd* i_f(nd *f)
{
    nd *t;
    t=(nd *)malloc(sizeof(nd));
    printf("Enter the employee details\n");
    scanf("%s%s%s%s%s",(t->d).usn,(t->d).nm,(t->d).br,(t->d).sem,(t->d).phno);
    t->link=f;
    return t;
}
nd* i_r(nd *f)
{
    nd *t;
    t=(nd *)malloc(sizeof(nd));
    printf("Enter the employee details\n");
    scanf("%s%s%s%s%s",(t->d).usn,(t->d).nm,(t->d).br,(t->d).sem,(t->d).phno);
    t->link=0;
    nd *l;
    for(l=f;l->link!=0;l=l->link);
    l->link=t;
    return f;
}

nd* d_f(nd *f)
{
    if(f==0)
    {
        printf("sll is empty");
        return 0;
    }
    if(f->link==0)
    {
        printf("The elements deleted are %s %s %s %s %s\n",(f->d).usn,(f->d).nm,(f->d).br,(f->d).sem,(f->d).phno);
        free(f);
        return 0;
    }
    nd *t=f->link;
    printf("The elements deleted are %s %s %s %s %s\n",(f->d).usn,(f->d).nm,(f->d).br,(f->d).sem,(f->d).phno);
        free(f);
        return t;
    
    
}

nd* d_r(nd *f)
{
     if(f==0)
    {
        printf("sll is empty");
        return 0;
    }
    if(f->link==0)
    {
        printf("The elements deleted are %s %s %s %s %s\n",(f->d).usn,(f->d).nm,(f->d).br,(f->d).sem,(f->d).phno);
        free(f);
        return 0;
    }
    nd *p,*c;
    for(p=0,c=f;c->link!=0;p=c,c=c->link);
    printf("The elements deleted are %s %s %s %s %s\n",(c->d).usn,(c->d).nm,(c->d).br,(c->d).sem,(c->d).phno);
    free(c);
    p->link=0;
    return f;
}
void display(nd *f)
{
    int count=0;
    for(;f!=0;f=f->link,count++)
    
        printf("The elements present are %s %s %s %s %s\n",(f->d).usn,(f->d).nm,(f->d).br,(f->d).sem,(f->d).phno);
        printf("No of nodes is %d\n",count);
}